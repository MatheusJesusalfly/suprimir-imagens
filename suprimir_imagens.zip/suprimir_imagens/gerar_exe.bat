@echo off
REM Gera SuprimirImagens.exe (rodar UMA vez em um Windows com Python instalado)
echo Instalando dependencias...
python -m pip install --upgrade pymupdf lxml pyinstaller || goto erro
echo Gerando executavel...
python -m PyInstaller --onefile --console --name SuprimirImagens --clean suprimir_imagens.py || goto erro
echo.
echo PRONTO: o executavel esta em dist\SuprimirImagens.exe
echo Copie so esse arquivo para o computador de trabalho.
pause
exit /b 0
:erro
echo.
echo ERRO - verifique se o Python esta instalado e marcado no PATH.
pause
exit /b 1
